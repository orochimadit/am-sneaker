<?php

/**
 * config duitku
 */

return [
    'merchant_code' => env('DUITKU_MERCHANT_CODE'),
    'merchant_key'  => env('DUITKU_MERCHANT_KEY'),
    'sandbox_mode'  => env('DUITKU_SANDBOX'),
];